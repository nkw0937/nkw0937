package tw.org.iii.drinks;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class ActOrder extends AppCompatActivity {

    int qty1 = 0;
    int qty2 = 0;
    int qty3 = 0;
    int rteaP = 0;
    int gteaP = 0;
    int mteaP = 0;
    int rteaS = 40; //小杯紅茶價
    int rteaM = 45; //中杯紅茶價
    int rteaL = 50; //大杯紅茶價
    int gteaS = 30; //小杯綠茶價
    int gteaM = 40; //中杯綠茶價
    int gteaL = 45; //大杯綠茶價
    int mteaS = 60; //小杯奶茶價
    int mteaM = 65; //中杯奶茶價
    int mteaL = 75; //大杯奶茶價
    String msg1 = "";
    String msg2 = "";
    String msg3 = "";
    String msg4 = "";
    String msg5 = "";
    String msg6 = "";
    String msg7 = "";
    String msg8 = "";
    String msg9 = "";

    //紅茶杯型
    private RadioGroup.OnCheckedChangeListener radiog1_click = new RadioGroup.OnCheckedChangeListener() {
        @Override
        public void onCheckedChanged(RadioGroup group, int checkedId) {
            if (checkedId == R.id.radiob1)
            {msg1 = radiob1.getText().toString();
                rteaP=rteaL;
                }
            else if (checkedId == R.id.radiob2)
            {msg1 = radiob2.getText().toString();
                rteaP=rteaM;}
            else if (checkedId == R.id.radiob3)
            {msg1 = radiob3.getText().toString();
                rteaP=rteaS;}
        }
    };

    //紅茶甜度
    private RadioGroup.OnCheckedChangeListener radiog2_click= new RadioGroup.OnCheckedChangeListener() {
        @Override
        public void onCheckedChanged(RadioGroup group, int checkedId) {
            if (checkedId == R.id.radiob4)
            {msg2 = radiob4.getText().toString();}
            else if (checkedId == R.id.radiob5)
            {msg2 = radiob5.getText().toString();}
            else if (checkedId == R.id.radiob6)
            {msg2 = radiob6.getText().toString();}
            else if (checkedId == R.id.radiob7)
            {msg2 = radiob7.getText().toString();}
            else if (checkedId == R.id.radiob8)
            {msg2 = radiob8.getText().toString();}
        }
    };

    //紅茶冰量
    private RadioGroup.OnCheckedChangeListener radiog3_click =new RadioGroup.OnCheckedChangeListener() {
        @Override
        public void onCheckedChanged(RadioGroup group, int checkedId) {
            if (checkedId == R.id.radiob9)
            {msg3 = radiob9.getText().toString();}
            else if (checkedId == R.id.radiob10)
            {msg3 = radiob10.getText().toString();}
            else if (checkedId == R.id.radiob11)
            {msg3 = radiob11.getText().toString();}
            else if (checkedId == R.id.radiob12)
            {msg3 = radiob12.getText().toString();}
            else if (checkedId == R.id.radiob13)
            {msg3 = radiob13.getText().toString();}
        }
    };

    //綠茶杯型
    private RadioGroup.OnCheckedChangeListener radiog4_click = new RadioGroup.OnCheckedChangeListener() {
        @Override
        public void onCheckedChanged(RadioGroup group, int checkedId) {
            if (checkedId == R.id.radiob14)
            {msg4 = radiob14.getText().toString();
                gteaP = gteaL;}
            else if (checkedId == R.id.radiob15)
            {msg4 = radiob15.getText().toString();
                gteaP = gteaM;}
            else if (checkedId == R.id.radiob16)
            {msg4 = radiob16.getText().toString();
                gteaP = gteaS;}
        }
    };

    //綠茶甜度
    private RadioGroup.OnCheckedChangeListener radiog5_click = new RadioGroup.OnCheckedChangeListener() {
        @Override
        public void onCheckedChanged(RadioGroup group, int checkedId) {
            if (checkedId == R.id.radiob17)
            {msg5 = radiob17.getText().toString();}
            else if (checkedId == R.id.radiob18)
            {msg5 = radiob18.getText().toString();}
            else if (checkedId == R.id.radiob19)
            {msg5 = radiob19.getText().toString();}
            else if (checkedId == R.id.radiob20)
            {msg5 = radiob20.getText().toString();}
            else if (checkedId == R.id.radiob21)
            {msg5 = radiob21.getText().toString();}
        }
    };


    //綠茶冰量
    private RadioGroup.OnCheckedChangeListener radiog6_click = new RadioGroup.OnCheckedChangeListener() {
        @Override
        public void onCheckedChanged(RadioGroup group, int checkedId) {
            if (checkedId == R.id.radiob22)
            {msg6 = radiob22.getText().toString();}
            else if (checkedId == R.id.radiob23)
            {msg6 = radiob23.getText().toString();}
            else if (checkedId == R.id.radiob24)
            {msg6 = radiob24.getText().toString();}
            else if (checkedId == R.id.radiob25)
            {msg6 = radiob25.getText().toString();}
            else if (checkedId == R.id.radiob26)
            {msg6 = radiob26.getText().toString();}
        }
    };


    //奶茶杯型
    private RadioGroup.OnCheckedChangeListener radiog7_click = new RadioGroup.OnCheckedChangeListener() {
        @Override
        public void onCheckedChanged(RadioGroup group, int checkedId) {
            if (checkedId == R.id.radiob27)
            {msg7 = radiob27.getText().toString();
                mteaP = mteaL;}
            else if (checkedId == R.id.radiob28)
            {msg7 = radiob28.getText().toString();
                mteaP = mteaM;}
            else if (checkedId == R.id.radiob29)
            {msg7 = radiob29.getText().toString();
                mteaP = mteaS;}
        }
    };

    //奶茶甜度
    private RadioGroup.OnCheckedChangeListener radiog8_click = new RadioGroup.OnCheckedChangeListener() {
        @Override
        public void onCheckedChanged(RadioGroup group, int checkedId) {
            if (checkedId == R.id.radiob30)
            {msg8 = radiob30.getText().toString();}
            else if (checkedId == R.id.radiob31)
            {msg8 = radiob31.getText().toString();}
            else if (checkedId == R.id.radiob32)
            {msg8 = radiob32.getText().toString();}
            else if (checkedId == R.id.radiob33)
            {msg8 = radiob33.getText().toString();}
            else if (checkedId == R.id.radiob34)
            {msg8 = radiob34.getText().toString();}
        }
    };


    //奶茶冰量
    private RadioGroup.OnCheckedChangeListener radiog9_click = new RadioGroup.OnCheckedChangeListener() {
        @Override
        public void onCheckedChanged(RadioGroup group, int checkedId) {
            if (checkedId == R.id.radiob35)
            {msg9 = radiob35.getText().toString();}
            else if (checkedId == R.id.radiob36)
            {msg9 = radiob36.getText().toString();}
            else if (checkedId == R.id.radiob37)
            {msg9 = radiob37.getText().toString();}
            else if (checkedId == R.id.radiob38)
            {msg9 = radiob38.getText().toString();}
            else if (checkedId == R.id.radiob39)
            {msg9 = radiob39.getText().toString();}
        }
    };


    private View.OnClickListener btnminus1_click = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            if (qty1 > 0) {
                qty1--;
                txtqty1.setText(String.valueOf(qty1));
                txttotal1.setText(String.valueOf(rteaP * qty1));
            }
        }
    };
    private View.OnClickListener btnminus2_click = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            if (qty2 > 0) {
                qty2--;
                txtqty2.setText(String.valueOf(qty2));
                txttotal2.setText(String.valueOf(gteaP * qty2));
            }
        }
    };
    private View.OnClickListener btnminus3_click = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            if (qty3 > 0) {
                qty3--;
                txtqty3.setText(String.valueOf(qty3));
                txttotal3.setText(String.valueOf(mteaP * qty3));
            }
        }
    };
    private View.OnClickListener btnadd1_click = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            qty1++;
            txtqty1.setText(String.valueOf(qty1));
            txttotal1.setText(String.valueOf(rteaP * qty1));
        }
    };
    private View.OnClickListener btnadd2_click = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            qty2++;
            txtqty2.setText(String.valueOf(qty2));
            txttotal2.setText(String.valueOf(gteaP * qty2));
        }
    };
    private View.OnClickListener btnadd3_click = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            qty3++;
            txtqty3.setText(String.valueOf(qty3));
            txttotal3.setText(String.valueOf(mteaP * qty3));
        }
    };
    private View.OnClickListener btnorder_click = new View.OnClickListener() {
        @Override
        public void onClick(View v) {

            SharedPreferences table=getSharedPreferences("T1", 0);
            int count=table.getInt("CNT",0);
            count++;
            table.edit().putInt("CNT",count).commit();
            String keyT="T"+String.valueOf(count);
             String str = "";
             if (qty1>0)
             {
                 str+= "紅茶" + msg1 + " " + msg2 + " " + msg3 + " " + "共" + qty1 + "杯，小計" + txttotal1.getText().toString() + "元" + "\n";
             }

             if (qty2>0)
             {
                 str+="綠茶" + msg4 + " " + msg5 + " " + msg6 + " " + "共" + qty2 + "杯，小計" +txttotal2.getText().toString() + "元" + "\n";
             }

             if (qty3>0)
             {
                 str+="奶茶" + msg7 + " " + msg8 + " " + msg9 + " " + "共" + qty3 + "杯，小計" +txttotal3.getText().toString() + "元" + "\n";
             }

            table.edit().putString(keyT,str).commit();

            Toast.makeText(ActOrder.this,"飲料訂購成功",Toast.LENGTH_LONG).show();
            Intent intent = new Intent(ActOrder.this,MainAct.class);
            startActivity(intent);
        }
    };
    private View.OnClickListener btncancel_click = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Toast.makeText(ActOrder.this, "取消訂購", Toast.LENGTH_LONG).show();
            finish();
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.act_order);
        InitialComponent();
    }
    
    

    public void InitialComponent()
    {
        radiog1 = findViewById(R.id.radiog1);
        radiog1.setOnCheckedChangeListener(radiog1_click);
        radiog2 = findViewById(R.id.radiog2);
        radiog2.setOnCheckedChangeListener(radiog2_click);
        radiog3 = findViewById(R.id.radiog3);
        radiog3.setOnCheckedChangeListener(radiog3_click);
        radiog4 = findViewById(R.id.radiog4);
        radiog4.setOnCheckedChangeListener(radiog4_click);
        radiog5 = findViewById(R.id.radiog5);
        radiog5.setOnCheckedChangeListener(radiog5_click);
        radiog6 = findViewById(R.id.radiog6);
        radiog6.setOnCheckedChangeListener(radiog6_click);
        radiog7 = findViewById(R.id.radiog7);
        radiog7.setOnCheckedChangeListener(radiog7_click);
        radiog8 = findViewById(R.id.radiog8);
        radiog8.setOnCheckedChangeListener(radiog8_click);
        radiog9 = findViewById(R.id.radiog9);
        radiog9.setOnCheckedChangeListener(radiog9_click);
        radiob1 = findViewById(R.id.radiob1);
        radiob2 = findViewById(R.id.radiob2);
        radiob3 = findViewById(R.id.radiob3);
        radiob4 = findViewById(R.id.radiob4);
        radiob5 = findViewById(R.id.radiob5);
        radiob6 = findViewById(R.id.radiob6);
        radiob7 = findViewById(R.id.radiob7);
        radiob8 = findViewById(R.id.radiob8);
        radiob9 = findViewById(R.id.radiob9);
        radiob10 = findViewById(R.id.radiob10);
        radiob11 = findViewById(R.id.radiob11);
        radiob12 = findViewById(R.id.radiob12);
        radiob13 = findViewById(R.id.radiob13);
        radiob14 = findViewById(R.id.radiob14);
        radiob15 = findViewById(R.id.radiob15);
        radiob16 = findViewById(R.id.radiob16);
        radiob17 = findViewById(R.id.radiob17);
        radiob18 = findViewById(R.id.radiob18);
        radiob19 = findViewById(R.id.radiob19);
        radiob20 = findViewById(R.id.radiob20);
        radiob21 = findViewById(R.id.radiob21);
        radiob22 = findViewById(R.id.radiob22);
        radiob23 = findViewById(R.id.radiob23);
        radiob24 = findViewById(R.id.radiob24);
        radiob25 = findViewById(R.id.radiob25);
        radiob26 = findViewById(R.id.radiob26);
        radiob27 = findViewById(R.id.radiob27);
        radiob28 = findViewById(R.id.radiob28);
        radiob29 = findViewById(R.id.radiob29);
        radiob30 = findViewById(R.id.radiob30);
        radiob31 = findViewById(R.id.radiob31);
        radiob32 = findViewById(R.id.radiob32);
        radiob33 = findViewById(R.id.radiob33);
        radiob34 = findViewById(R.id.radiob34);
        radiob35 = findViewById(R.id.radiob35);
        radiob36 = findViewById(R.id.radiob36);
        radiob37 = findViewById(R.id.radiob37);
        radiob38 = findViewById(R.id.radiob38);
        radiob39 = findViewById(R.id.radiob39);
        txtqty1 = findViewById(R.id.txtqty1);
        txtqty2 = findViewById(R.id.txtqty2);
        txtqty3 = findViewById(R.id.txtqty3);
        txttotal1 = findViewById(R.id.txttotal1);
        txttotal2 = findViewById(R.id.txttotal2);
        txttotal3 = findViewById(R.id.txttotal3);
        btnminus1 = findViewById(R.id.btnminus1);
        btnminus1.setOnClickListener(btnminus1_click);
        btnminus2 = findViewById(R.id.btnminus2);
        btnminus2.setOnClickListener(btnminus2_click);
        btnminus3 = findViewById(R.id.btnminus3);
        btnminus3.setOnClickListener(btnminus3_click);
        btnadd1 = findViewById(R.id.btnadd1);
        btnadd1.setOnClickListener(btnadd1_click);
        btnadd2 = findViewById(R.id.btnadd2);
        btnadd2.setOnClickListener(btnadd2_click);
        btnadd3 = findViewById(R.id.btnadd3);
        btnadd3.setOnClickListener(btnadd3_click);
        btnorder = findViewById(R.id.btnorder);
        btnorder.setOnClickListener(btnorder_click);
        btncancel = findViewById(R.id.btncancel);
        btncancel.setOnClickListener(btncancel_click);
    }

    RadioGroup radiog1;
    RadioGroup radiog2;
    RadioGroup radiog3;
    RadioGroup radiog4;
    RadioGroup radiog5;
    RadioGroup radiog6;
    RadioGroup radiog7;
    RadioGroup radiog8;
    RadioGroup radiog9;
    RadioButton radiob1;
    RadioButton radiob2;
    RadioButton radiob3;
    RadioButton radiob4;
    RadioButton radiob5;
    RadioButton radiob6;
    RadioButton radiob7;
    RadioButton radiob8;
    RadioButton radiob9;
    RadioButton radiob10;
    RadioButton radiob11;
    RadioButton radiob12;
    RadioButton radiob13;
    RadioButton radiob14;
    RadioButton radiob15;
    RadioButton radiob16;
    RadioButton radiob17;
    RadioButton radiob18;
    RadioButton radiob19;
    RadioButton radiob20;
    RadioButton radiob21;
    RadioButton radiob22;
    RadioButton radiob23;
    RadioButton radiob24;
    RadioButton radiob25;
    RadioButton radiob26;
    RadioButton radiob27;
    RadioButton radiob28;
    RadioButton radiob29;
    RadioButton radiob30;
    RadioButton radiob31;
    RadioButton radiob32;
    RadioButton radiob33;
    RadioButton radiob34;
    RadioButton radiob35;
    RadioButton radiob36;
    RadioButton radiob37;
    RadioButton radiob38;
    RadioButton radiob39;
    Button btnminus1;
    Button btnminus2;
    Button btnminus3;
    Button btnadd1;
    Button btnadd2;
    Button btnadd3;
    Button btnorder;
    Button btncancel;
    EditText txtqty1;
    EditText txtqty2;
    EditText txtqty3;
    TextView txttotal1;
    TextView txttotal2;
    TextView txttotal3;
}
