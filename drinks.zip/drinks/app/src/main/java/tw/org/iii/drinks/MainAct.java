package tw.org.iii.drinks;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

public class MainAct extends AppCompatActivity {

        private View.OnClickListener btnclear_click = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            android.content.SharedPreferences table =getSharedPreferences("T1", 0);
            //int count=table.getInt("CNT",0);
            table.edit().clear().commit();

        }
    };


    private View.OnClickListener btnstartorder_click = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Intent intent = new Intent(MainAct.this,ActOrder.class);
            startActivity(intent);
        }
    };
    private View.OnClickListener btnorderlist_click = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            android.content.SharedPreferences table=getSharedPreferences("T1", 0);
            int count=table.getInt("CNT",0);
            String str1 = "";
            for(int i=1; i<count +1; i++){
                    str1 += table.getString("T" + String.valueOf(i), "No Data") + "\n";
            }
            android.widget.Toast.makeText(MainAct.this,str1,android.widget.Toast.LENGTH_LONG).show();

        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.act_main);
        InitialComponent();
    }




    private void InitialComponent()
    {
        btnstartorder=findViewById(R.id.btnstartorder);
        btnstartorder.setOnClickListener(btnstartorder_click);
        btnorderlist=findViewById(R.id.btnorderlist);
        btnorderlist.setOnClickListener(btnorderlist_click);
        btnclear=findViewById(R.id.btnclear);
        btnclear.setOnClickListener(btnclear_click);
    }
    Button btnclear;
    Button btnstartorder;
    Button btnorderlist;
}
